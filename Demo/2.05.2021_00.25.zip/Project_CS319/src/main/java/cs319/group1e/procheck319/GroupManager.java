package cs319.group1e.procheck319;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class GroupManager {
    private GroupRepository groupRepository;
    public GroupManager(GroupRepository groupRepository){
        this.groupRepository = groupRepository;
    }
}
