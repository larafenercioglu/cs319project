package com.example.yeter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YeterApplication {

    public static void main(String[] args) {
        SpringApplication.run(YeterApplication.class, args);
    }

}
