package com.example.yeter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YeterApplicationTests {

    @Test
    void contextLoads() {
    }

}
