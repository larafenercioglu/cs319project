package com.example.newdemo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping
public class UserController {

    @Autowired
    private UserRepository userRepository;

    public UserController(UserRepository theUserRepository) {
        userRepository = theUserRepository;
    }

    //Open Login page
    @GetMapping("/login")
    public String getMain(Model theModel) {

        // create model attribute to bind form data
        User theUser = new User();

        theModel.addAttribute("user", theUser);
        return "loginIndex";
    }

    //Login the system
    @PostMapping(value = "/checkUserInput")
    public String checkUserByLoginInput(@ModelAttribute("user") User theUser) {

        //Get email and password
        String email = theUser.getEmail();
        String password = theUser.getPassword();

        User user = new User();

        List<User> newList = userRepository.findAll();
        for(int i  = 0; i < newList.size(); i++) {
            if(newList.get(i).getEmail().equals(email) && newList.get(i).getPassword().equals(password)) {
                theUser.setUserName(newList.get(i).getUserName());
                theUser.setUserSurname(newList.get(i).getUserSurname());
                theUser.setUserId(newList.get(i).getUserId());

                return "dashboardIndex";
            }
        }
        return "redirect:/login";
    }

    //Update an user
    @GetMapping("/update/{userId}")
    public String updateUserById(@PathVariable int userId, @ModelAttribute("user") User theUser) {

        User user = userRepository.findByUserId(userId);

        theUser.setUserName(user.getUserName());
        theUser.setUserSurname(user.getUserSurname());
        theUser.setUserId(user.getUserId());
        theUser.setEmail(user.getEmail());
        theUser.setPassword(user.getPassword());

        return "dashboardIndex";
    }

    @PostMapping("/save")
    public String saveUser(@ModelAttribute("user") User theUser) {

        // save the user
        userRepository.save(theUser);

        // use a redirect to prevent duplicate submissions
        return "redirect:/login";
    }

    /*
    @GetMapping(value = "/all")
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
     */

    /*
    @GetMapping(value = "/{userId}")
    public boolean checkUserById(@PathVariable("userId") int id) {

        List<User> newList = userRepository.findAll();
        for(int i  = 0; i < newList.size(); i++) {
            if(newList.get(i).getUserId() == id) {
                return true;
            }
        }
        return false;
    }
    */

    /*
    @PostMapping
    public String createUser(@RequestBody User user) {
        User newUser = userRepository.insert(user);
        return "User " + newUser.getUserName() + " created";
    }
    */

    /*
    @PutMapping(value = "/{userId}")
    public boolean updateUser(@PathVariable("userId") int id, @RequestBody User user ) {

        if(user.getUserId() == id) {
            userRepository.save(user);
            return true;
        }
        else {
            return false;
        }
    }
    */

    /*
    @DeleteMapping(value = "delete/{userId}")
    public String deleteUser(@PathVariable("userId") int id) {
        userRepository.deleteById(id);
        return "redirect:/login";
    }
    */

}

