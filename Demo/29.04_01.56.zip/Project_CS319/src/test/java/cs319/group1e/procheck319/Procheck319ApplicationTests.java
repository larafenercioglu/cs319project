package cs319.group1e.procheck319;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Procheck319ApplicationTests {

    @Test
    void contextLoads() {
    }

}
