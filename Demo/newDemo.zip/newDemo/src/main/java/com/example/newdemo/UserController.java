package com.example.newdemo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping
public class UserController {

    @Autowired
    private UserRepository userRepository;

    public UserController(UserRepository theUserRepository) {
        userRepository = theUserRepository;
    }

    //Open Login page
    @GetMapping("/login")
    public String getMain(Model theModel) {

        // create model attribute to bind form data
        User theUser = new User();

        theModel.addAttribute("user", theUser);
        return "loginIndex";
    }

    //Login the system
    @PostMapping(value = "/checkUserInput")
    public String checkUserByLoginInput(@ModelAttribute("user") User theUser) {

        String email = theUser.getEmail();
        String password = theUser.getPassword();

        List<User> newList = userRepository.findAll();
        for(int i  = 0; i < newList.size(); i++) {
            if(newList.get(i).getEmail().equals(email) && newList.get(i).getPassword().equals(password)) {
                return "dashboardIndex";
            }
        }
        return "redirect:/login";
    }


    /*
    @GetMapping(value = "/all")
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

     */

    /*
    @GetMapping(value = "/{userId}")
    public boolean checkUserById(@PathVariable("userId") int id) {

        List<User> newList = userRepository.findAll();
        for(int i  = 0; i < newList.size(); i++) {
            if(newList.get(i).getUserId() == id) {
                return true;
            }
        }
        return false;
    }
    */

    /*
    @GetMapping(value = "/{email}/{password}")
    public boolean checkUserByLoginInput(@PathVariable("email") String email, @PathVariable("password") String password ) {

        List<User> newList = userRepository.findAll();
        for(int i  = 0; i < newList.size(); i++) {
            if(newList.get(i).getEmail().equals(email) && newList.get(i).getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }
    */
    /*
    @PostMapping
    public String createUser(@RequestBody User user) {
        User newUser = userRepository.insert(user);
        return "User " + newUser.getUserName() + " created";
    }
    */

    /*
    @PostMapping("/save")
    public String saveUser(@ModelAttribute("user") User theUser) {

        // save the user
        userRepository.save(theUser);

        // use a redirect to prevent duplicate submissions
        return "redirect:/login";
    }
    */

    /*
    @PutMapping(value = "/{userId}")
    public boolean updateUser(@PathVariable("userId") int id, @RequestBody User user ) {

        if(user.getUserId() == id) {
            userRepository.save(user);
            return true;
        }
        else {
            return false;
        }
    }
    */

    /*
    @DeleteMapping(value = "delete/{userId}")
    public String deleteUser(@PathVariable("userId") int id) {
        userRepository.deleteById(id);
        return "redirect:/login";
    }
    */

}

