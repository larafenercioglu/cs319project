package com.example.newdemo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DbSeeder implements CommandLineRunner {

    private UserRepository userRepository;

    public DbSeeder(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        User bedo = new User("Bedirhan", "Sakinoglu" , "bedo123", 21801, "bedisakinoglu@gmail.com");
        User gok = new User("Gokhan", "Tas" , "fener", 21802, "gokhan@gmail.com");
        User tutku = new User("Utku","Sezer", "sebo", 21803, "darnque@gmail.com");
        User lara = new User("Lara", "Fenerci", "yes", 21804, "lara@ug.bilkent.edu.tr");
        User kim = new User("Kimya","Ghasem", "kimya", 21805, "kimya@ug.bilkent.edu.tr");

        this.userRepository.deleteAll();
        List<User> users = Arrays.asList(bedo,gok,tutku,lara,kim);
        this.userRepository.saveAll(users);

    }
}
