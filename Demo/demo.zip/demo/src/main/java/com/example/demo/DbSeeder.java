package com.example.demo;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DbSeeder implements CommandLineRunner {

    private UserRepository userRepository;

    public DbSeeder(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        User bedo = new User("Bedirhan", "Sakinoglu" , "bedo123", 21801, "bedisakinoglu@gmail.com","student");
        User gok = new User("Gokhan", "Tas" , "fener", 21802, "gokhan@gmail.com","student");
        User tutku = new User("Utku","Sezer", "sebo", 21803, "darnque@gmail.com","student");
        User lara = new User("Lara", "Fenerci", "yes", 21804, "lara@ug.bilkent.edu.tr","student");
        User kim = new User("Kimya","Ghasem", "kimya", 21805, "kimya@ug.bilkent.edu.tr","student");
        User tuzun = new User("Eray","Tüzün","pony",2143,"eray.tuzun@bilkent.edu.tr", "instructor");
        User tuna = new User("Erdem","Tuna","letmecheckit",21402,"erdem.tuna@ug.bilkent.edu.tr", "instructor");
        User jabra = new User("Elgun","Jabra","github",21501,"elgun.jabra@ug.bilkent.edu.tr", "instructor");

        //this.userRepository.deleteAll();
        List<User> users = Arrays.asList(bedo,gok,tutku,lara,kim,tuzun,tuna,jabra);
        this.userRepository.saveAll(users);
    }
}