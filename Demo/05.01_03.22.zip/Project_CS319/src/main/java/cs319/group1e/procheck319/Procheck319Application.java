package cs319.group1e.procheck319;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

@SpringBootApplication
public class Procheck319Application {

    public static void main(String[] args) {
        SpringApplication.run(Procheck319Application.class, args);
    }
}
