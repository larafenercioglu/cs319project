package cs319.group1e.procheck319;

public class Announcement {
    private String context;
    private String title;

    public Announcement(String context, String title) {
        this.context = context;
        this.title = title;
    }
    //TODO : Constructor, getter, setter eklenecek

}
